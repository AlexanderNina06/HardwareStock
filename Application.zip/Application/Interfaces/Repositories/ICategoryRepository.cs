﻿using HardwareStock.Core.Domain.Entities;


namespace HardwareStock.Core.Application.Interfaces.Repositories
{
    public interface ICategoryRepository : IGenericRepository<Category>
    {
        

    }
}
