﻿using HardwareStock.Core.Domain.Entities;


namespace HardwareStock.Core.Application.Interfaces.Repositories
{
    public interface IProductRepository: IGenericRepository<Product>
    {
       

    }
}
